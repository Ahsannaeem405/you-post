<!DOCTYPE HTML>
<html lang="en-US">
<head>
    <!--Metatags-->
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta http-equiv="X-UA-Compatble" content="ie=edge"/>
    <!--Website Title-->
    <title>YOUPOST</title>

    <meta property="og:title" content="Preview">
    <meta property="og:description" content="Description of your page or content">
    <meta property="og:url" content="youpost.social">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aHVtYW58ZW58MHx8MHx8fDA%3D&w=1000&q=80">


</head>

<body style="background-color: #0c4128">
    <h1 style="text-align: center;background-color: #0a53be;color: white">This is post preview page.</h1>

    <img src="https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aHVtYW58ZW58MHx8MHx8fDA%3D&w=1000&q=80" width="100%" alt="">
</body>

</html>
