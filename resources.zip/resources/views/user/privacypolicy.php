<style>
      body{
      margin:0;
      padding:0;
      font-family: 'arial';
    }
    body *{box-sizing: border-box;}
    .Heading {
      width: 100%;
      height: 200px;
      padding: 65px 20px;
      text-align: center;
      background: #43c35e;
      color: #fff;
      font-size: 30px;
    }
    .Heading h2 {
      margin: 0;
    }
    .inner-content {
      max-width: 1200px;
      margin: 0 auto;
      background: #fff;
      margin-top: -30px;
      padding: 20px;
      width: 98%;
      box-shadow: 0px 0px 11px 3px #ccc;
    }
</style>
<div class="Heading">
    <h2>Privacy Policy</h2>
  </div>

<div class="inner-content">
<h3>What is our Privacy Policy?</h3>

<p>We recognize that your privacy is very important and take it seriously. This Privacy Policy describes <b>Post Scheduler</b> policies and procedures on the collection, use and disclosure of your information when you use the <b>Post Scheduler</b> Service. We will not use or share your information with anyone except as described in this Privacy Policy. </p>

<p>This Privacy Policy does not apply to information we collect by other means (including offline) or from other sources. Capitalized terms that are not defined in this Privacy Policy have the meaning given them in our Terms of Service.</p>

<p>All Our The Information of Your's is collected by a form in our website. We are not allowed to share your personal information or image with other person or any website. Your All Information is secure and trusted.</p>

<h3>'pages_show_list','pages_read_engagement','pages_read_user_content' ,'pages_manage_posts','read_insights' </h3>

<p> For a better experience while using our Service, We may require you to allow us to post on your behalf. </p>

</div> 
