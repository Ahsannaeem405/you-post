<div class="sidenav-overlay"></div>
<div class="drag-target"></div>
<footer class="footer footer-static footer-light" style="bottom:0; position:fixed">
    <p class="clearfix blue-grey lighten-2 mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT &copy; 2024<a class="text-bold-800 grey darken-2" href="javascript:void(0)" target="_blank">,</a>All rights Reserved</span></p>
</footer>