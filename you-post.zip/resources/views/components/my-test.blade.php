<div>
    call me {{$testVar}} {{$ok}}
</div>
